/******************************************************************************
26(уровень A)
В базе данных филателиста содержатся сведения о личной коллекции марок.
Структура входного файла in.txt (Марка Страна Номер альбома Год выпуска Цена)
Розовый_маврикий Маврикий 15 1847 1000000
Черный_пенни Великобритания 15 1840 5000
Голубой_маврикий Маврикий 14 1847 2000000
...
Определить стоимость марок по странам, упорядочив по названию страны
Структура выходного файла out.txt
Страна Стоимость
Великобритания 5000
Маврикий 3000000
*******************************************************************************/
#include <stdio.h>     
#include <stdlib.h>   
#include <string.h>    
typedef struct {    // Структуру Stamp для хранения информации о марке
    char mark[1000];
    char country[1000];
    int album;
    int year;
    int price;
} Stamp;

int main() {    
    FILE *input_file = fopen("in.txt", "r");    
    FILE *output_file = fopen("out.txt", "w");  

    if (input_file == NULL || output_file == NULL) {   // Проверяем успешное открытие файлов
        printf("Ошибка открытия файлов\n");    
        return 1;    
    }

    Stamp stamps[100];    // Объявляем массив структур для хранения данных о марках
    int num = 0;    // счетчик

    while (fscanf(input_file, "%s %s %d %d %d", stamps[num].mark, stamps[num].country,     
                  &stamps[num].album, &stamps[num].year, &stamps[num].price) == 5) {
        num++;    
    }

    // Сортировка по странам
    for (int i = 0; i < num; i++) {    // Пузырьковая сортировка
        for (int j = i + 1; j < num; j++) {    
            if (strcmp(stamps[i].country, stamps[j].country) > 0) {    
                Stamp temp = stamps[i];    
                stamps[i] = stamps[j];     
                stamps[j] = temp;
            }
        }
    }

    fprintf(output_file, "Страна Стоимость\n");   

    int total_price = 0;    // Переменная для хранения общей суммы стоимости
    for (int i = 0; i < num; i++) {    // Цикл для подсчета общей стоимости по каждой стране
        if (i > 0 && strcmp(stamps[i].country, stamps[i - 1].country) != 0) {
            fprintf(output_file, "%s %d\n", stamps[i - 1].country, total_price);    // Записываем данные по стране
            total_price = 0;    // Обнуляем сумму после записи
        }
        total_price += stamps[i].price;    // Увеличиваем общую стоимость
    }

    if (num > 0) {
        fprintf(output_file, "%s %d\n", stamps[num - 1].country, total_price);    // Записываем данные последней страны
        
    }
    int total = 0;  // Переменная для хранения общей суммы стоимости

    for (int i = 0; i < num; i++) {
    total += stamps[i].price;  // Добавляем стоимость каждой марки к общей сумме
    }


    fprintf(output_file, "Итог: %d\n", total);   
    

    fclose(input_file);    
    fclose(output_file);  

    return 0;    
}


