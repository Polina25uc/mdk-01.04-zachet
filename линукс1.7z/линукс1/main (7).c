#include <stdio.h>
#include <string.h>
#include <sys/stat.h>

#define MAX_LINE_LENGTH 256

int main() {
    FILE *file;
    char line[MAX_LINE_LENGTH];

    // Открываем файл "poli.csv" для чтения
    file = fopen("polina.csv", "r");
    if (!file) {
        perror("Ошибка открытия файла");
        return 1;
    }

    // Читаем файл построчно и создаем папки
    while (fgets(line, MAX_LINE_LENGTH, file)) {
        size_t len = strlen(line);
        if (len > 0 && line[len - 1] == '\n') {
            line[len - 1] = '\0'; // Удаляем символ новой строки в конце строки
        }

        // Создаем папку
        if (mkdir(line, 0755) == -1) {
            perror("Ошибка создания папки");
            continue;
        }

        printf("Папка '%s' успешно создана.\n", line);
    }

    fclose(file);
    printf("Все папки из файла 'poli.csv' успешно созданы.\n");

    return 0;
}

