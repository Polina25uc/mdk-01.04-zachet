#include "mark.h"
#include <stdio.h>
#include <string.h>

void write_marks_to_file() {
    FILE *fp_in = fopen("mark.txt", "r");
    FILE *fp_in1 = fopen("strana.txt", "r");
    Mark marks[MAX_MARKS]; 
    int num_marks = 0;
    char line[100];
    
    while (fgets(line, sizeof(line), fp_in1)) {
        char country[50];int album;int year;
        int index, price, found = 0;

        sscanf(line, "%d %s %d %d %d", &index, country, &album, &year, &price)==4;

        for (int i = 0; i < num_marks; i++) {
            if (strcmp(marks[i].country, country) == 0) {
                marks[i].total_price += price;
                found = 1;
                break;
            }
        }

        if (!found) {
            strcpy(marks[num_marks].country, country);
            marks[num_marks].total_price = price;
            num_marks++;
        }
    }
    fclose(fp_in);
    fclose(fp_in1); // Закрыть файл in.txt после его чтения
    
    // Сортировка данных о странах по общей стоимости каждой
    bubbleSort(marks, num_marks); 
    
    FILE *fp_out = fopen("out.txt", "w");

    // Запись отсортированных данных в out.txt
    fprintf(fp_out, "Страна Стоимость\n");
    for (int i = 0; i < num_marks; i++) {
        fprintf(fp_out, "%s %d\n", marks[i].country, marks[i].total_price);
    }
    fclose(fp_out);  // Закрыть файл out.txt после записи
    
    printf("Данные успешно записаны в out.txt и отсортированы по общей стоимости заказов\n");
}