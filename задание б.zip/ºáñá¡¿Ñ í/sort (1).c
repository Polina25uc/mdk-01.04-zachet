#include "mark.h"

void bubbleSort(Mark *marks, int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (marks[j].total_price < marks[j + 1].total_price) {
                Mark temp = marks[j];
                marks[j] = marks[j + 1];
                marks[j + 1] = temp;
            }
        }
    }
}
