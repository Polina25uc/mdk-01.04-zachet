#include "mark.h"
#include <stdio.h>
#include <string.h>

void add_mark() {
    // Определяем временные переменные для хранения входных данных
    int next_index;char mark[50], country[50];
    int album;
    int year;
    int price;

    // Запрашиваем у пользователя ввести данные в одну строку
    printf("Введите данные ( Индекс Марка_товара Страна количество год цена): ");
    scanf(" %d %49s %49s %d %d %d",&next_index, mark, country, &album, &year, &price);
    
    getchar(); // Убираем символ новой строки из ввода

    // Открываем файл для добавления записи
    FILE *fp_in = fopen("mark.txt", "a");
    FILE *fp_in1 = fopen("strana.txt", "a");
    // Записываем данные в файл
    fprintf(fp_in, "%d %s \n", next_index, mark);
    fprintf(fp_in1, "%d %s %d %d %d\n", next_index, country, album, year, price);
    fclose(fp_in); // Закрываем файл
    fclose(fp_in1); 
    strcpy(marks[num_marks].country, country);

    marks[num_marks].total_price = price;
    num_marks++;

    printf("Запись добавлена успешно.\n");
}