#include "mark.h"

Mark marks[MAX_MARKS];
int num_marks = 0;

int main(void) {
    display_menu();
    return 0;
}