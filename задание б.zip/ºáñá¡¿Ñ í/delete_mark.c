#include "mark.h"
#include <stdio.h>

void delete_mark() {
    int delete_index;
    printf("ВНИМАНИЕ: Если вы удалите запись с введенным индексом, то удалятся все данные с данным индексом\n");
    printf("Введите индекс записи о марке для удаления: ");
    scanf("%d", &delete_index);
    getchar(); // Чтобы очистить буфер ввода от символа новой строки
   
    FILE *fp_in = fopen("mark.txt", "r");
    FILE *fp_in1 = fopen("strana.txt", "r");
    FILE *fp_temp = fopen("temp.txt", "w");
    FILE *fp_temp1 = fopen("temp1.txt", "w");
    char line[100];
    int index;
    // Читаем исходный файл
    while (fgets(line, sizeof(line), fp_in1) != NULL) {
        // Считываем индекс записи
        sscanf(line, "%d", &index);
        // Проверяем, не является ли текущая строка той, что нужно удалить
        if (index != delete_index) {
            fputs(line, fp_temp1); // Записываем строку во временный файл
        }
    }
    while (fgets(line, sizeof(line), fp_in) != NULL) {
        // Считываем индекс записи
        sscanf(line, "%d", &index);
        // Проверяем, не является ли текущая строка той, что нужно удалить
        if (index != delete_index) {
            fputs(line, fp_temp); // Записываем строку во временный файл
        }
    }
    fclose(fp_in); 
    fclose(fp_in1);// Закрываем исходный файл
    fclose(fp_temp); // Закрываем временный файл
    fclose(fp_temp1);
    // Удаляем исходный файл и переименовываем временный файл в in.txt
    remove("mark.txt");
    rename("temp.txt", "mark.txt");
    remove("strana.txt");
    rename("temp1.txt", "strana.txt");
    printf("Запись с индексом %d удалена.\n", delete_index);
}