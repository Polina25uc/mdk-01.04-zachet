#include "mark.h"
#include <stdio.h>

void print_all_marks() {
    FILE *fp_in = fopen("mark.txt", "r");
    FILE *fp_in1 = fopen("strana.txt", "r");
    char line[100];
    printf("Индекс Марка_товара\n");
    while (fgets(line, sizeof(line), fp_in) != NULL) {
        printf("%s", line);  // Вывод строки из файла
    }
    fclose(fp_in); 
    printf("Индекс Страна Количество Год Стоимость\n");
    while (fgets(line, sizeof(line), fp_in1) != NULL) {
        printf("%s", line);  // Вывод строки из файла
    }
    fclose(fp_in1); // Закрыть файл после использования
}