#include "mark.h"
#include <stdio.h>

void edit_mark() {
    char new_mark[50], new_country[50]; int new_album;int new_year;
    int new_price;
    int edit_index;
    printf("Введите марку записи, которую нужно отредактировать: ");
    scanf("%d", &edit_index);
    getchar(); // Очистка буфера

    printf("Введите новые данные: ");
    scanf("%49s %49s %d %d %d", new_mark, new_country, &new_album, &new_year, &new_price);

    getchar(); // Очистка буфера

    FILE *fp_in = fopen("mark.txt", "r");
    FILE *fp_in1 = fopen("strana.txt", "r");
    FILE *fp_temp = fopen("temp.txt", "w");
    FILE *fp_temp1 = fopen("temp1.txt", "w");

    char line[100];
    int index;
    while (fgets(line, sizeof(line), fp_in) != NULL) {
        sscanf(line, "%d", &index);
        if (index == edit_index) {
            // Вставляем новую информацию вместо старой строки.
           fprintf(fp_temp, "%d %s\n", edit_index, new_mark);
        } else {
            // Если это не строка, которую мы редактировали, просто переписываем её.
            fputs(line, fp_temp);
        }
    }
    while (fgets(line, sizeof(line), fp_in1) != NULL) {
        sscanf(line, "%d", &index);
        if (index == edit_index) {
            // Вставляем новую информацию вместо старой строки.
           fprintf(fp_temp1, "%d %s %d %d %d\n", edit_index, new_country, new_album, new_year, new_price);
        } else {
            // Если это не строка, которую мы редактировали, просто переписываем её.
            fputs(line, fp_temp1);
        }
    }
    fclose(fp_in);
    fclose(fp_temp);
    fclose(fp_in1);
    fclose(fp_temp1);

    // удаление исходного файла и изменение имени временного файла, чтобы заменить исходный
    remove("mark.txt");
    rename("temp.txt", "mark.txt");
    remove("strana.txt");
    rename("temp1.txt", "strana.txt");
    printf("Запись с индексом %d обновлена.\n", edit_index);
}