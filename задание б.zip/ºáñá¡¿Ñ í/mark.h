#ifndef REPAIR_H
#define REPAIR_H

#define MAX_MARKS 100

typedef struct {
    char country[50];
    int total_price;
} Mark;

struct Strana {
    int next_index;
    char country[50];
    int album;
    int year;
    int price;
};



extern Mark marks[MAX_MARKS];
extern int num_marks;

void bubbleSort(Mark *marks, int n);
void add_mark();
void delete_mark();
void edit_mark();
void print_all_marks();
void write_marks_to_file();
void display_menu();

#endif // REPAIR_H