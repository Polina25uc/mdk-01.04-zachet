#include "mark.h"
#include <stdio.h>

void display_menu() {
    int choice;

    while (1) {
        printf("\nМеню:\n");
        printf("1. Выход\n");
        printf("2. Добавить запись о марке\n");
        printf("3. Удалить запись о марке\n");
        printf("4. Редактировать запись о марке\n");
        printf("5. Распечатать все записи о марке\n");
        printf("6. Записать запрос в файл\n");
        printf("Выберите опцию: ");
        scanf("%d", &choice);
        printf("\n");

        switch (choice) {
            case 1: // Выход
                return;
            case 2: // Добавить запись о марке
                add_mark();
                break;
            case 3: // Удалить запись о марке
                delete_mark();
                break;
            case 4: // Редактировать запись о марке
                edit_mark();
                break;
            case 5: // Распечатать все записи о марке
                print_all_marks();
                break;
            case 6: // Записать все записи в файл
                write_marks_to_file();
                break;
            default:
                printf("Неверный выбор. Пожалуйста, попробуйте снова.\n");
        }
    }
}