import os
import zipfile
# Функция для чтения строк из файла и возврата списка строк
def zipka(filename):
    with open(filename, 'r') as file:
        return file.read().splitlines()
# Чтение строк из файла 'word.txt' в список
listt = zipka('word.txt')
# Перебор каждой строки из 'word.txt'
for line in listt:
    # Создание имени ZIP-архива на основе текущей строки
    zip_file = '{}.zip'.format(line.lower())
    # Создание нового ZIP-архива для каждой строки
    with zipfile.ZipFile(zip_file, 'w') as zipf:
        # Перебор файлов в текущем каталоге
        for filename in os.listdir('.'):
            # Проверка является ли файл файлом с расширением .txt и не является ли он 'word.txt'
            if filename.endswith('.txt') and filename != 'word.txt':
                # Чтение строк из текущего файла
                zipkaa = zipka(filename)

                # Проверка, есть ли текущая строка среди строк текущего файла
                if line in zipkaa:
                    zipf.write(filename)
